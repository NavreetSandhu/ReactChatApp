
import React from 'react';
import ReactStars from 'react-stars';

export default () => {
  const ratingChanged = (newRating) => {
    // console.log(newRating);
  };
  return (
    <div className="sidebar green-sidebar black-sidebar">
      <ul>
        <li>
          <div className="redo-button text-center">
            <button className="btn">Apply
                                <i className="fas fa-redo"></i>
            </button>
          </div>
        </li>
        <li>
          <span className="left-label float-left">Availability</span>
          <span className="right-label float-right">
            <label className="switch white-switch">
              <input type="checkbox" />
              <span className="slider round"></span>
            </label>
          </span>
        </li>
        <li>
          <span className="left-label float-left">Rating</span>
          <span className="right-label float-right">
            <ReactStars
              count={5}
              size={18}
              value={3.5}
              onChange={ratingChanged}
              color2={'#D2F035'}
            />
          </span>
        </li>
        <li>
          <span className="left-label float-left">Price</span>
          <span className="right-label float-right">
            Hi - Low
                        </span>
        </li>
        <li>
          <span className="left-label float-left">Vehicle age</span>
          <span className="right-label float-right">
            <label className="switch white-switch">
              <input type="checkbox" />
              <span className="slider round"></span>
            </label>
          </span>
        </li>
        <li>
          <span className="left-label float-left">Years exp.</span>
          <span className="right-label float-right">
            10 - 15 yrs
                        </span>
        </li>
        <li>
          <span className="left-label float-left">Owner/operator</span>
          <span className="right-label float-right">
            <label className="switch">
              <input type="checkbox" />
              <span className="slider round"></span>
            </label>
          </span>
        </li>
        <li>
          <span className="left-label float-left">Company</span>
          <span className="right-label float-right">
            <label className="switch">
              <input type="checkbox" />
              <span className="slider round"></span>
            </label>
          </span>
        </li>
        <li>
          <span className="left-label float-left">Distance</span>
          <span className="right-label float-right">
            30 - 100 Kms
                        </span>
        </li>
        <li>
          <span className="left-label float-left">ISO Credentials</span>
          <span className="right-label float-right">
            <label className="switch">
              <input type="checkbox" />
              <span className="slider round"></span>
            </label>
          </span>
        </li>
        <li>
          <div className="redo-button text-center">
            <button className="btn">Clear Search</button>
          </div>
        </li>
      </ul>
    </div>
  );
};