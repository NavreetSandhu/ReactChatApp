import React from 'react';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import Loader from '../Loader';
import { logout } from '../../actions/user';

const header = ({
  loader,
  user,
  logout,
  history
}) => {

  /********** Logout user *********/ 
  const logoutUser = (token) => {
    //logout(token, res => {
    //  if (res) {
//       
//      }
//}
      history.push('/');

  };
  return (
    <div className="header">
      <div className="container-fluid">
        <div className="row roww align-items-center">
          <div className="col-md-4 col-sm-4 col-4">
            
                  </div>
            <div className="col-md-4 col-sm-4 col-4 text-center">
                      <div className="logo">
                          <h3>athleque</h3>
                      </div>
            </div>
          <div className="col-md-4 col-sm-4 col-4 text-right">
            
            <div className="menu">
              <div className="dropdown">
              
                                  <div className="mobile-sidebar-icon d-none" data-toggle="dropdown">
                                      <div className="sr-icon"></div>
                                      <div className="sr-icon"></div>
                                      <div className="sr-icon"></div>
                                  </div>
                <div className="dropdown-menu">
                  <a className="dropdown-item" href="#">My Profile</a>
                  <a className="dropdown-item" href="#" onClick={() => logoutUser(user.data.loginToken)}>Logout</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Loader loading={loader.isFetching} />
    </div>
  );
};

header.propTypes = {
  loader: PropTypes.object.isRequired,
  user: PropTypes.object.isRequired,
  logout: PropTypes.func.isRequired
};

const mapStateToProps = state => ({
  user: state.user,
  loader: state.loader
});

const mapDispatchToProps = dispatch => ({
  logout: bindActionCreators(logout, dispatch)
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(header));