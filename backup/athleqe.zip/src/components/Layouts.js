/*
 * @file: Layouts.js
 * @description: Defined all Layouts for application
 * @author: smartData
*/

import React from 'react';
import Header from './headers/Header';
import MainHeader from './headers/MainHeader';
import Footer from './footers/Footer';
import MainFooter from './footers/MainFooter';
import SideBar from './SideBar';

/*************** Public Layout ***************/
export const publicLayout = props => {
  window.scrollTo(0, 0);
  const path = props.children.props.history.location.pathname;
  return (
        <div className="container">{props.children}</div>
  );
};

/*************** Private Layout ***************/
export const privateLayout = props => {
  window.scrollTo(0, 0);
  return (
    <div className="main">
      <div className="green-customer-header green-search-header">
              <MainHeader />
      </div>
      <div className=" content-wrapper">
            {props.children}
          </div>
      </div>
     
  );
};
