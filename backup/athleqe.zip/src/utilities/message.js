/*
 * @file: messages.js
 * @description: Handle staic messages for the application
 * @author: smartData
 */

const Message = {
  emptyField: 'Please enter value.',
  success: 'Success!',
  error: 'Error!',
  commonError: 'Something went wrong!',
  logout: 'Logout!',
  invalidEmail: 'Please enter valid email.',
  invalidPass: 'Password must be 6 to 10 as min & max characters respectively.',
    skillRequired: 'Skills are required.',
    locationRequired: 'Location is required.'

};

module.exports = Message;
