/*
 * @file: constants.js
 * @description: It Contain action types Related Action.
 * @author: smartData
 */

/************ User *************/
export const public_type = 'public';
export const private_type = 'private';
export const dashboard_path = 'search-result';
export const GOOGLE_API_KEY = 'AIzaSyCXFFY6CzwOJXV4cc_Trk7mGp_U2h7izAw';