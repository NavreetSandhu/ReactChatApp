import { JWT, file } from '../environment';

/************ Get file path *****************/
export const getFile = path => {
  if (path.includes('http', 'https')) {
    return path;
  } else {
    return `${file}/file/${path}`;
  }
};




