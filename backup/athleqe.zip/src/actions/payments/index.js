/*
 * @file: index.js
 * @description: It Contain user related Action Creators.
 * @author: smartData
 */

import * as TYPE from '../constants';
import ApiClient from '../../api-client';
import { apiUrl } from '../../environment';
import { toastAction } from '../toast-actions';

export const is_fetching = (status) => ({ type: TYPE.IS_FETCHING, status });

//**** Thunk Action Creators For Api ****//
