/*
 * @file: index.js
 * @description: It Contain files related Action Creators.
 * @author: smartData
 */

import * as TYPE from '../constants';
import ApiClient from '../../api-client';
import { file } from '../../environment';
import { toastErrorAction } from '../toast-actions';
import { apiUrl } from '../../environment';

export const is_fetching = (status) => ({ type: TYPE.IS_FETCHING, status });
export const update_skills = (data) => ({ type: TYPE.SKILL_LIST, data });

/****** action creator for getting skills list ********/
export const getSkills = (token) => {
    return dispatch => {
        dispatch(is_fetching(true));
        ApiClient.post(`${apiUrl}/getSkills`).then(response => {
            if (response.status === 200) {
                dispatch(is_fetching(false));
                dispatch(update_skills(response.data));
                // callback(true);
            } else {
                dispatch(is_fetching(false));
                // callback(false);
            }
        });
    };
};