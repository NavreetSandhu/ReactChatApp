/*
 * @file: constants.js
 * @description: It Contain action types Related Action constants.
 * @author: smartData
 */

/************ Loading *************/
export const IS_FETCHING = 'IS_FETCHING';

/************ User *************/
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const ROLE_SET = 'ROLE_SET';
export const LOG_OUT = 'LOG_OUT';
export const UPDATE_PROFILE = 'UPDATE_PROFILE';

/************ Skills *************/
export const SKILL_LIST = 'SKILL_LIST';




