/*
 * @file: index.js
 * @description: It Contain user related Action Creators.
 * @author: smartData
 */

import * as TYPE from '../constants';
import ApiClient from '../../api-client';
import { apiUrl } from '../../environment';
import { toastAction } from '../toast-actions';

export const is_fetching = (status) => ({ type: TYPE.IS_FETCHING, status });
export const login_success = (data) => ({ type: TYPE.LOGIN_SUCCESS, data });
export const logout_user = () => ({ type: TYPE.LOG_OUT });
export const update_profile = (data) => ({ type: TYPE.UPDATE_PROFILE, data });
export const roleSetup = (role) => ({ type: TYPE.ROLE_SET ,role});
export const signupData = (data) => ({ type: TYPE.UPDATE_PROFILE, data });

//**** Thunk Action Creators For Api ****//
/****** action creator for login ********/
export const login = (params, callback) => {
  return dispatch => {
    dispatch(is_fetching(true));
    ApiClient.post(`${apiUrl}/login`, params).then(response => {
      if (response.status === 200) {
        dispatch(is_fetching(false));
        toastAction(true, response.msg);
        dispatch(login_success(response.data));
        callback(true);
      } else {
        dispatch(is_fetching(false));
        toastAction(false, response.msg);
        callback(false);
      }
    });
  };
};

/****** action creator for signup ********/
export const signup = (params, callback) => {
  return dispatch => {
    dispatch(is_fetching(true));
    ApiClient.post(`${apiUrl}/signup`, params).then(response => {
      if (response.status === 200) {
        dispatch(is_fetching(false));
        toastAction(true, response.message);
        callback(true);
      } else {
        dispatch(is_fetching(false));
          toastAction(false, response.message);
        callback(false);
      }
    });
  };
};

/****** action creator for resend email verification link ********/
export const resendEmailLink = (params, callback) => {
  return dispatch => {
    dispatch(is_fetching(true));
    ApiClient.post(`${apiUrl}/user/resend-email`, params).then(response => {
      if (response.statusCode === 200) {
        dispatch(is_fetching(false));
        toastAction(true, response.msg);
        callback(true);
      } else {
        dispatch(is_fetching(false));
        toastAction(false, response.msg);
        callback(false);
      }
    });
  };
};

/****** action creator for account verification ********/
export const accountVerification = (token,callback) => {
  return dispatch => {
    dispatch(is_fetching(true));
    ApiClient.get(`${apiUrl}/user/${token}`).then(response => {
      if (response.status === 200) {
        dispatch(is_fetching(false));
        toastAction(true, response.msg);
        dispatch(login_success(response.data));
         callback(true);
      } else {
        dispatch(is_fetching(false));
        toastAction(false, response.msg);
         callback(false);
      }
    });
  };
};

/****** action creator for forgotpassword ********/
export const forgotPassword = (params, callback) => {
  return dispatch => {
    dispatch(is_fetching(true));
    ApiClient.put(`${apiUrl}/user/forgot-password`, params).then(response => {
      if (response.statusCode === 200) {
        dispatch(is_fetching(false));
        // toastAction(true, response.message); commented by poonam to removed error mesasge on enterig wrong email
        callback(true);
      } else {
       dispatch(is_fetching(false));
        // toastAction(false, response.message);  commented by poonam to removed error mesasge on enterig wrong email
        callback(true);
      }
    });
  };
};

/****** action creator for resetPassword ********/
export const resetPassword = (params, callback) => {
  return dispatch => {
    dispatch(is_fetching(true));
    ApiClient.put(`${apiUrl}/user/password`, { password: params.password }, params.token).then(response => {
      if (response.statusCode === 200) {
        dispatch(is_fetching(false));
        // toastAction(true, response.message); commented by poonam to removed error mesasge on enterig wrong email
        callback(true);
      } else {
        dispatch(is_fetching(false));
        toastAction(false, response.msg);
        callback(false);
      }
    });
  };
};



/****** action creator for logout ********/
export const logout = (token, callback) => {
  return dispatch => {
    dispatch(is_fetching(true));
    ApiClient.delete(`${apiUrl}/user/logout`, token).then(response => {
      if (response.statusCode === 200) {
        dispatch(is_fetching(false));
        dispatch(logout_user());
        callback(true);
      } else {
        dispatch(is_fetching(false));
        toastAction(false, response.msg);
        callback(true);
      }
    });
  };
};

/****** action creator for updating user details ********/
export const updateProfile = (params, callback) => {
  return (dispatch, getState) => {
        const {
          data: { loginToken }
        } = getState().user;
    dispatch(is_fetching(true));
    ApiClient.put(`${apiUrl}/user`, params ,loginToken).then(response => {
      if (response.statusCode === 200) {
        dispatch(is_fetching(false));
        dispatch(update_profile(response.data));
        toastAction(true, response.msg); 
        callback(true);
      } else {
       dispatch(is_fetching(false));
        toastAction(false, response.msg);
        callback(true);
      }
    });
  };
};

/****** action creator for  user details ********/
export const getProfile = (params, callback) => {
    return (dispatch, getState) => {
        const {
            data: { loginToken }
        } = getState().user;
        dispatch(is_fetching(true));
        ApiClient.put(`${apiUrl}/user`, params, loginToken).then(response => {
            if (response.statusCode === 200) {
                dispatch(is_fetching(false));
                dispatch(update_profile(response.data));
                toastAction(true, response.msg);
                callback(true);
            } else {
                dispatch(is_fetching(false));
                toastAction(false, response.msg);
                callback(true);
            }
        });
    };
};

