/*
 * @file: index.js
 * @description: It Contain environment variables.
 * @author: smartData
 */

const local = {
    apiUrl: 'http://54.190.192.105:6037/api/v1',
    socketUrl: 'http://172.24.5.81:3000',
    file: 'http://54.190.192.105:6037/api',

};
const production = {
    apiUrl: 'http://54.190.192.105:6037/api/v1',
    socketUrl: 'http://3.18.168.191:3005',
    file: 'http://54.190.192.105:6037/api',

};

if (process.env.NODE_ENV === 'production') {
  module.exports = production;
} else {
  module.exports = local;
}
