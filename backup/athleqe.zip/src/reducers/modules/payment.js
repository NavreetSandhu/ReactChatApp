/*
 * @file: product.js
 * @description: Reducers and actions for store/manipulate user's  data
 * @author: smartData
*/

import * as TYPE from '../../actions/constants';

/******** Reducers ********/
const initialState = {
  data: null,
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    default:
      return state;
  }
}
