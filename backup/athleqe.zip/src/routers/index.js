
/*********** Routes for applications **************/

import React from 'react';
import { Switch } from 'react-router-dom';
import { publicLayout, privateLayout } from '../components/Layouts';
import AppRoute from './AppRoute';
import { Auth } from '../auth';
import { public_type, private_type } from '../utilities/constants';
import NotFound from '../components/NoFound';
import LoginPage from '../containers/login';
import ForgotPassword from '../containers/forgot-passord/index';
import SignUp from '../containers/signup/index';
import VerifyEmail from '../containers/verify-account';
import RoleSetup from '../containers/signup/role-setup';
import Profile from '../containers/dashboard';


const Routers = store => {
  return (
    <Switch>
      <AppRoute
        exact={true}
        path="/"
        component={LoginPage}
        requireAuth={Auth}
        layout={publicLayout}
        store={store}
        type={public_type}
      />
      <AppRoute
        exact
        path="/login"
        component={LoginPage}
        requireAuth={Auth}
        layout={publicLayout}
        store={store}
        type={public_type}
      />
       <AppRoute
        exact
        path="/forgot-password"
        component={ForgotPassword}
        requireAuth={Auth}
        layout={publicLayout}
        store={store}
        type={public_type}
      />
      <AppRoute
        exact
        path="/reset-password/:token"
        component={ForgotPassword}
        requireAuth={Auth}
        layout={publicLayout}
        store={store}
        type={public_type}
      />
      
      <AppRoute
        exact
        path="/signup"
        component={SignUp}
        requireAuth={Auth}
        layout={publicLayout}
        store={store}
        type={public_type}
      />
      <AppRoute
        exact
        path="/account-verification/:token"
        component={VerifyEmail}
        requireAuth={Auth}
        layout={publicLayout}
        store={store}
        type={public_type}
      />
     
      
      <AppRoute
        exact
        path="/role-setup"
        component={RoleSetup}
        requireAuth={Auth}
        layout={publicLayout}
        store={store}
        type={public_type}
          />
       <AppRoute
              exact
              path="/profile"
              component={Profile}
              requireAuth={Auth}
              layout={privateLayout}
              store={store}
              type={public_type}
        />
      <AppRoute
        exact
        path="*"
        component={NotFound}
        requireAuth={Auth}
        layout={publicLayout}
        store={store}
        type={public_type}
      />      
    </Switch>
  );
};

export default Routers;