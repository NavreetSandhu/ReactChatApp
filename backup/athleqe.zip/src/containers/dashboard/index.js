/*
 * @file: dahboard.js
 * @description: It is Container dashboard screen .
 * @author: smartData
 */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { getProfile } from '../../actions/user';
import ProfessionalProfile from './professionalProfile';
import UserProfile from './userProfile';


class Profile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            
        };
        
    }

    componentDidMount() {
        //let { getProfile } = this.props;
        //getProfile();
    }

    render() {
        return (
            <div>
            {
                    this.props.user.role === 'client' &&
                    <UserProfile />
            } 
            {
                    this.props.user.role === 'professional' &&
                     <ProfessionalProfile />
                }
         </div>
        );
    }
}

Profile.propTypes = {
    getProfile: PropTypes.func.isRequired,
};
const mapStateToProps = state => ({
    user: state.user,
});

const mapDispatchToProps = dispatch => ({
    getProfile: bindActionCreators(getProfile, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Profile);
