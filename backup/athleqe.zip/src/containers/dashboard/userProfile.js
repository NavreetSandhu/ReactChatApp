/*
 * @file: professional.js
 * @description: It is Container search result screen .
 * @author: smartData
 */
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { getFile } from '../../utilities/common';
import { Row, Col, Button, FormGroup, Label } from 'reactstrap';

const UserProfile = ({ match, history }) => {

    const user = useSelector(state => state.user);
    const dispatch = useDispatch();

    return (user.data &&
        <div >
            <Row >
                <Col sm="4">
                    <Row>
                        <Col sm="12">
                            <div className="profile-image text-center border">
                                <div className="images">
                                    {user.data.image && user.data.image != '' && user.data.image != "https://i.stack.imgur.com/l60Hf.png" &&
                                        <img src={user.data.image} alt="operator image" height="130" width="130" />
                                    }
                                    {!user.data.image &&
                                        <img src="https://i.stack.imgur.com/l60Hf.png" alt="operator image" height="130" width="130" />
                                    }

                                </div>
                                <div className="profile-details p-4 text-center">
                                    <h3 >First Name Last</h3>
                                   
                                  

                                </div>
                                <div className="profiles-btns  text-center">
                                    <div className="profile-details">
                                        <Link to="/"> <button type="submit" className="btn empty-btn m-1 mb-3"> Connect </button></Link>
                                        <button type="submit" className="btn green-btn m-1 mb-3">Message</button>
                                    </div>
                                </div>
                            </div>
                        </Col>
                        
                        
                        <Col sm="12">
                            <div className="profile-image  border">

                                <div className="profile-details p-4 ">
                                    <h3 >Social</h3>
                                </div>
                                <div className="profiles-btns">
                                    <div className="profile-details text-center">
                                        <p>
                                            <img className="img-fluid" src={require("../../assets/images/footer-social-icons.png")} alt="social-icons" />
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </Col>
                        
                    </Row>
                </Col>
                <Col col="8">
                    <Row>
                        <Col sm="12">
                            <div className="profile-image  border">

                                <div className="profile-details p-4 border">
                                    <h3 >About Me</h3>
                                    <p>Complete the following fields so you don�t have to worry about making payment every time you want to nudgit </p>
                                </div>
                            </div>
                        </Col>
                        
                       
                    </Row>
                </Col>

            </Row>

        </div>
    );
};


export default UserProfile;