/*
 * @file: professional.js
 * @description: It is Container search result screen .
 * @author: smartData
 */
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { getFile } from '../../utilities/common';
import { Row, Col, Button, FormGroup, Label } from 'reactstrap';

const ProfessionalProfile = ({ match, history }) => {

    const user = useSelector(state => state.user);
    const dispatch = useDispatch();

    //useEffect(()=>{
    //  console.log(operator);
    //  if(!operator.details){
    //    dispatch(operatorProfile(match.params.id)); 
    //    }
    //    return ()=>{
    //      dispatch(clear_operator_profile());
    //    };
    //},[]);

    return (user.data &&
        <div >
        <Row >
            <Col sm="4">
                <Row>
                    <Col sm="12">
                        <div className="profile-image text-center border">
                    <div className="images">
                        {user.data.image && user.data.image != '' && user.data.image != "https://i.stack.imgur.com/l60Hf.png" &&
                                    <img src={user.data.image} alt="operator image" height="130" width="130" />
                        }
                        {!user.data.image &&
                            <img src="https://i.stack.imgur.com/l60Hf.png" alt="operator image" height="130" width="130" />
                        }
                        
                      </div>
                            <div className="profile-details p-4 text-center">
                                <h3 >First Name Last</h3>
                                <p>Title here</p>
                                <p className="green-font">Taking New CLients!</p>
                               
                            </div>
                            <div className="profiles-btns  text-center">
                                <div className="profile-details">
                                    <Link to="/"> <button type="submit" className="btn empty-btn m-1 mb-3"> Connect </button></Link>
                                    <button type="submit" className="btn green-btn m-1 mb-3">Message</button>
                                    <p>Price:$20-$30</p>
                                </div>
                            </div>
                </div>
                    </Col>
                    <Col sm="12">
                        <div className="profile-image  border">
                     
                            <div className="profile-details p-4 ">
                                <h3 >Key Skills</h3>
                                
                            </div>
                            <div className="profiles-btns">
                                <div className="profile-details">
                                    <button type="submit" className="btn green-btn m-1 mb-3">Skill 1</button>
                                </div>
                            </div>
                        </div>
                    </Col>
                    <Col sm="12">
                        <div className="profile-image  border">

                            <div className="profile-details p-4 ">
                                <h3 ><i className="fa fa-map-marker"></i> <i className="fa fa-map-marker"></i><i className="fa fa-map-marker"></i>Location</h3>
                            </div>
                            <div className="profiles-btns text-center">
                                <div className="profile-details">
                                   <p>Address here</p>
                                </div>
                            </div>
                        </div>
                    </Col>
                    <Col sm="12">
                        <div className="profile-image  border">

                            <div className="profile-details p-4 ">
                                <h3 >Social</h3>
                            </div>
                            <div className="profiles-btns">
                                <div className="profile-details text-center">
                                    <p>
                                        <img className="img-fluid" src={require("../../assets/images/footer-social-icons.png")} alt="social-icons" />
                                    </p>
                                </div>
                            </div>
                        </div>
                    </Col>
                    <Col sm="12">
                        <div className="profile-image  border">

                            <div className="profile-details p-4 ">
                                <h3 >Connections</h3>
                            </div>
                            <div className="profiles-btns">
                                <div className="profile-details">
                                    <ul>
                                        <li><Link to="#">
                                            <h3>Nae here</h3>
                                            <p>Description herer</p></Link></li>
                                        <li><Link to="#">
                                            <h3>Nae here</h3>
                                            <p>Description herer</p></Link></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </Col>
             </Row>
            </Col>
            <Col col="8">
                <Row>
                    <Col sm="12">
                    <div className="profile-image  border">

                            <div className="profile-details p-4 border">
                                <h3 >About Me</h3>
                                <p>Complete the following fields so you don�t have to worry about making payment every time you want to nudgit </p>
                            </div>
                    </div>
                    </Col>
                    <Col sm="12">
                        <div className="profile-image  border">

                            <div className="profile-details p-4 border">
                                <h3 >Gallery</h3>
                                <div className="lightBoxGallery">
                                    <a href="img/gallery/1.jpg" title="Image from Unsplash" data-gallery=""><img src="http://webapplayers.com/inspinia_admin-v2.9.3/img/gallery/6s.jpg" /></a>
                                    <a href="img/gallery/1.jpg" title="Image from Unsplash" data-gallery=""><img src="http://webapplayers.com/inspinia_admin-v2.9.3/img/gallery/4s.jpg"/></a>
                                  </div>
                            </div>
                        </div>
                    </Col>
                    <Col sm="12">
                        <div className="profile-image  border">

                            <div className="profile-details p-4 border">
                                <h3 >Qualification</h3>
                                <ul>
                                    <li>
                                        <p>Qualification 1</p></li>
                                    <li><p>Description herer</p></li>
                                </ul>
                            </div>
                        </div>
                    </Col>
                    <Col sm="12">
                        <div className="profile-image  border">

                            <div className="profile-details p-4 border">
                                <h3 >Recommendations</h3>
                                <div class="contact-box p-4 ">
                                    <div className="row">
                                        <div className="col-4">
                                            <div className="text-center">
                                                <img alt="image" className="rounded-circle m-t-xs img-fluid" height="40" width="40" src="https://i.stack.imgur.com/l60Hf.png"/>
                                                    <div class="m-t-xs font-bold">Graphics designer</div>
                                             </div>
                                            </div>
                                            <div className="col-8">
                                                <h3><strong>John Smith</strong></h3>
                                                <p> Professional</p>
                                               <p>Complete the following fields so you don�t have to worry about making payment every time you want to nudgit </p>

                                                </div>
                                                    </div>
                                </div>
                            </div>
                            </div>
                    </Col>
                </Row>
            </Col>
                
        </Row>
           
        </div>
    );
};


export default ProfessionalProfile;