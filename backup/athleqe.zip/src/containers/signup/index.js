/*
 * @file: login.js
 * @description: It is Container login screen .
 * @author: smartData
 */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import SignupForm from '../form/signup';
import { signup, resendEmailLink, signupData } from '../../actions/user';
import SignupSuccess from './signup-success';
import RoleSetup from './role-setup';
import ProfileBasics from '../form/profilebasics';
import { uploadFile } from '../../actions/file';
import * as moment from 'moment';
import Loader from '../../components/Loader';

class SignUp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            image: '',
            step: 1,
            selectedSkills: null,
            address: '',
            lat_lng: null,
            locationModal: false,
            radius: 0,
            ImageCropModal: false,
            imageToCrop: '',
            skill_error: false,
            location_error: false,
            price: [0, 0],
            activity: false,
            confirm_error:false,

        };
        this.handleSignup = this.handleSignup.bind(this);
        this.handleResendLink = this.handleResendLink.bind(this);
        this.handleStep = this.handleStep.bind(this);
        this.handleRegistration = this.handleRegistration.bind(this);
        this._uploadPhoto = this._uploadPhoto.bind(this);
        this.onSelect = this.onSelect.bind(this);
        this.getAddress = this.getAddress.bind(this);
        this._toggleModal = this._toggleModal.bind(this);
        this.updateLocation = this.updateLocation.bind(this);
        this.openCropper = this.openCropper.bind(this);
        this.toggleShow = this.toggleShow.bind(this);
        this.setPrice = this.setPrice.bind(this);
        this.handleActivity = this.handleActivity.bind(this);
    }

    //handle activity change
    handleActivity() {
        this.setState({ activity: !this.state.activity });
    }

    toggleShow() {
        this.setState({ hidden: !this.state.hidden });
    }

    // Handle user Signup
    handleSignup(values) {
        this.setState({
            skill_error: false
        });
        this.setState({
            location_error: false
        });
        const { signup } = this.props;
        if (this.state.address != '' && this.state.selectedSkills != null && this.state.selectedSkills != [] || this.props.user.role == 'client') {
            const skill_array = this.state.selectedSkills.map((skills) => {
                return skills.value;
            });
            let obj = {};
            if (this.props.user.role === "professional") {
                 obj = {
                    "role": 1,
                    "firstName": this.props.user.data.firstName,
                    "lastName": this.props.user.data.lastName,
                    "email": this.props.user.data.email,
                    "password": this.props.user.data.password,
                    "gender": this.props.user.data.gender,
                    "dob": moment(this.props.user.data.dob).format('YYYY-MM-DD'),
                    "enquiry": this.props.user.data.enquiry,
                    "title": values.title,
                    "radius": values.radius,
                    "address": this.state.address,
                    "lat": this.state.lat_lng[0],
                    "lng": this.state.lat_lng[1],
                    "priceMax": this.state.price[1],
                    "priceMin": this.state.price[0],
                    "activityStatus": this.state.activity,
                    "currency": values.currency,
                    "profilePic": this.state.image,
                    "skills": skill_array,
                };
            }
            else {
                obj = {
                    "role": 2,
                    "firstName": this.props.user.data.firstName,
                    "lastName": this.props.user.data.lastName,
                    "email": this.props.user.data.email,
                    "password": this.props.user.data.password,
                    "gender": this.props.user.data.gender,
                    "dob": this.props.user.data.dob,
                    "enquiry": this.props.user.data.enquiry,
                    "profilePic": this.state.image
                };
            }
            //signup(obj, res => {
            //    if (res) {
                    this.setState({ step: 4 });
            //    }
                
            //});
          
            
        }
        else {
            if (this.state.address == '') {
                this.setState({ location_error: true });
            }
            if (this.state.selectedSkills === null || this.state.selectedSkills === []) {
                this.setState({
                    skill_error: true
                });
            }
        }

      
    };

    handleRegistration(e, date) {
        const { signupData } = this.props;
        this.setState({ confirm_error: false });
        if (e.password != e.confirmpassword) {
            this.setState({ confirm_error: true });
            console.log(this.state.confirm_error);
        }
        else {

            signupData({ ...e, ...{ "dob": date } });
            this.setState({ step: 3 });
        }
    }

    // Handle the resend email verification link
    handleResendLink(email) {
        const { resendEmailLink } = this.props;
        //resendEmailLink({ email: email }, res => {
        //    if (res) {
        //        console.log(res);
        //        // history.push('/search-result');
        //    }
        //});

        console.log(email);
    };

    // Upload File 
    _uploadPhoto(file, type) {
        //if (!file[0]) {
        //    return;
        //}
        this.setState({
                    image: file
                });
        //uploadOperatorImage(file[0], (status, data) => {
        //    if (status) {
        //        this.setState({
        //            image: data.fileName
        //        });
        //    }
        //});
    }

    handleStep(e) {
        this.setState({ step: e });
    }

    //set price range

    setPrice(e) {
        this.setState({ price: e });
    }


    // On skill select
    onSelect = (selctedData) => {
        this.setState({ selectedSkills: selctedData });
        console.log(this.state.selectedSkills);
    }

    //fnc for searching location
    getAddress = (address, lat_lng) => {
        var lat_lng = Object.values(lat_lng);
        lat_lng.reverse();
        this.setState({ address: address, lat_lng: lat_lng });
        console.log(address, lat_lng);
    };

    // togglemodal
    _toggleModal = status => {
        console.log(status);
        this.setState({
            locationModal: status
        });
    };

    // toggleimagemodal
    _toggleImageModal = status => {
        console.log(status);
        this.setState({
            ImageCropModal: status
        });
    };

    updateLocation = () => {
        this._toggleModal(true);
    };

    openCropper = (e) => {
        const reader = new FileReader();
        reader.readAsDataURL(e);
        reader.onload = function () {
            console.log('reader.result', reader.result);
            this.setState({ imageToCrop: reader.result });
            //self.sendFileToServer(reader.result)
        }.bind(this);
        reader.onerror = function (error) {
            console.log('Error: ', error);
        };
        this.setState({
            ImageCropModal: true
        });
    };



    render() {
        return (
            <div>
                <div className="login-form" >

                    {this.state.step != 4 &&
                        <div className="steps">
                            <span className={this.state.step === 1 ? "step active" : "step"}></span>
                            <span className={this.state.step === 2 ? "step active" : "step"}></span>
                            <span className={this.state.step === 3 ? "step active" : "step"}></span>

                        </div>
                    }

                    {this.state.step === 1 &&
                        <RoleSetup _handleStep={(e) => this.handleStep(e)} />
                    }
                    {
                        this.state.step === 2
                        &&
                        <SignupForm _handleRegistration={(e, date) => this.handleRegistration(e, date)} confirm_error={this.state.confirm_error} />
                    }
                    {
                        this.state.step === 3 &&
                        <ProfileBasics
                            deleteImage={() => this.setState({image:''})}
                            role={this.props.user.role}
                            image={this.state.image}
                            uploadPhoto={(file, type) => this._uploadPhoto(file, type)}
                            _handleSignup={this.handleSignup}
                            _resendLink={this.handleResendLink}
                            onSelect={this.onSelect}
                            skill_error={this.state.skill_error}
                            location_error={this.state.location_error}
                            skills={this.props.skills.list}
                            selectedSkills={this.state.selectedSkills}
                            getAddress={this.getAddress}
                            address={this.state.address}
                            locationModal={this.state.locationModal}
                            toggleModal={this._toggleModal}
                            lat_lng={this.state.lat_lng}
                            radius={this.state.radius}
                            updateRadius={(value) => this.setState({ radius: value })}
                            ImageCropModal={this.state.ImageCropModal}
                            toggleImageModal={this._toggleImageModal}
                            openCropper={this.openCropper}
                            imageToCrop={this.state.imageToCrop}
                            submit={this.handleSignup}
                            hidden={this.state.hidden}
                            price={this.state.price}
                            setPrice={this.setPrice}
                            activity={this.state.activity}
                            _handleActivity={this.handleActivity}
                        />
                    }
                    {
                        this.state.step === 4 &&
                        <SignupSuccess
                            email={this.props.user.data.email}
                            _resendLink={this.handleResendLink}
                        ></SignupSuccess>

                    }
                </div>
                <Loader loading={this.props.loader.isFetching} />

            </div>


        );
    }

}
SignUp.propTypes = {
    signup: PropTypes.func.isRequired,
    resendEmailLink: PropTypes.func.isRequired,
    loader: PropTypes.object.isRequired,

};
const mapStateToProps = state => ({
    user: state.user,
    skills: state.skill,
    loader: state.loader,
});

const mapDispatchToProps = dispatch => ({
    signup: bindActionCreators(signup, dispatch),
    resendEmailLink: bindActionCreators(resendEmailLink, dispatch),
    signupData: bindActionCreators(signupData, dispatch),
    uploadOperatorImage: bindActionCreators(uploadFile, dispatch),

});

export default connect(mapStateToProps, mapDispatchToProps)(SignUp);
