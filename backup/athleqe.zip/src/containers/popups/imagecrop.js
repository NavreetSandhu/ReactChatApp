import React, { useRef,useState, useEffect } from 'react';
import { Row, Col, Button, FormGroup, Label } from 'reactstrap';
import Cropper from 'react-cropper';
import fs from 'fs';
import 'cropperjs/dist/cropper.css'; 

export default ({ uploadPhoto, image, showHideImagePopup,popup}) => {
    const cropper = useRef();
    const [file, setFile] = useState('');
    const _crop = () => {
        // image in dataUrl
        var base = cropper.current.cropper.getCroppedCanvas().toDataURL();
        setFile(base);
    };

    const save = () => {
        uploadPhoto(file, 'image');
    };
    return (

        <div
            className={`modal fade custom-fade ${popup && 'show d-block'}`}
            id="select-operator-popup-form"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="select-operator-popup-formLabel"
            aria-hidden="true"
        >
            <div className="modal-dialog" role="document">
                <div className="modal-content operator-modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title"  id="add-operator-popup-formLabel">
                            Crop the Photo
            </h5>
                        <button
                            type="button"
                            className="close"
                            data-dismiss="modal"
                            aria-label="Close"
                            onClick={() => {
                                showHideImagePopup(false);

                            }}
                        >
                            <span aria-hidden="true">
                                <i className="fa fa-close"></i>
                            </span>
                        </button>
                    </div>
                    <div className="modal-body" >
                        <div>
                        <Row>

                        <Cropper
                            ref={cropper}
                            src={image}
                            style={{ height: 400, width: '100%' }}
                            // Cropper.js options
                            aspectRatio={9 / 9}
                            guides={false}
                            crop={_crop} />

                        </Row>
                        <br></br>
                        <Row>
                            <div className="modal-header pd">
                            <button
                                type="button"
                                className="btn btn-sm  btn-secondary"
                              
                                onClick={() => {
                                    save();
                                    showHideImagePopup(false);

                                }}
                            >
                                    Save
                            </button>
                            </div>
                            <div className="modal-header pd">
                            <button
                                type="button"
                                className="btn btn-sm  btn-secondary"
                               
                                onClick={() => {
                                    showHideImagePopup(false);

                                }}
                            >
                                    Cancel
                            </button>
                            </div>
                            </Row>
                        </div>
                    </div>
                </div>
            </div >
        </div >
    );
};

 
