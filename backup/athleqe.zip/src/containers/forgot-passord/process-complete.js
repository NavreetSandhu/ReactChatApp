import React from 'react';
export default () => {
  return (
    <div className="forgot-password-success-message">
      <form>
        
        <div className="heading-text">
          <span>Well done</span>
        </div>
        <div className="sub-heading-text">
          <span>We’ve sent you an email. Click on the link in your email and use the code to reset your password.</span>
        </div>
      </form>
    </div>
  );
};