import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { LocalForm, Control } from 'react-redux-form';
import Errors from '../../components/common/errors';
import Loader from '../../components/Loader';
import Match from '../../utilities/validation';
import { invalidEmail, passMismatch } from '../../utilities/message';
import { forgotPassword, resetPassword } from '../../actions/user';
import { toastAction } from '../../actions/toast-actions';
import ProcessCompelete from './process-complete';
import ResetPassword from './reset-password';

const ForgotPassword = ({
  user,
  match,
  forgotPassword,
  resetPassword
}) => {
  const params = match.params;
  const [status, setStatus] = useState(null);
  /******** Handle submit **********/
  const handleSubmit = values => {
    forgotPassword({...values, type:'web'}, res => setStatus(res));
  };
  /******* Handle reset password  *******/
  const handleResetPassword = values => {
    if (values.password.trim() === values.new_password.trim()) {
      resetPassword({ password: values.password, token: params.token }, res => setStatus(res));
    } else {
      toastAction(false, passMismatch);
    }
  };

  return (
    <div className="container-fluid no-right-padd-container-fluid">
      <div className="row">
        <Loader loading={user.isFetching} />
        <div className="col-md-12">
          <div className="login-form admin-login-form">
            {!params['token'] ? status === null || status === false ?
              <div className={status === null ? 'forgot-password' : 'forgot-password forgot-password-wrong-email'}>
                <LocalForm
                  model="user"
                  onSubmit={(values) => handleSubmit(values)}
                >
                  {status === null &&
                    <React.Fragment>

                      <div className="heading-text">
                        <span>Password Restoration</span>
                      </div>
                      <div className="sub-heading-text">
                        <span>Just enter the email address used to create your account</span>
                      </div>
                    </React.Fragment>

                  }

                  <div className="form-group margin-top-40">
                    <Control.text
                      model="user.email"
                      className="form-control"
                      type="email"
                      id="user.email"
                      placeholder="Email address"
                      errors={{
                        required: (val) => !val || !val.length,
                        invalidEmail: (val) => !Match.validateEmail(val)
                      }}
                    />
                    <Errors
                      model="user.email"
                      errors={{
                        invalidEmail
                      }}
                    />
                  </div>
                  <button type="submit" className="btn btn-primary">Submit
                  </button>
                </LocalForm>
              </div>
              :
              <ProcessCompelete />
              : <ResetPassword resetPassword={handleResetPassword} status={status} />
            }
          </div>
        </div>
      </div>
      
    </div>
  );
};

ForgotPassword.propTypes = {
  user: PropTypes.object.isRequired,
  match: PropTypes.object.isRequired,
  forgotPassword: PropTypes.func.isRequired,
  resetPassword: PropTypes.func.isRequired
};

const mapStateToProps = state => ({
  user: state.user
});

const mapDispatchToProps = dispatch => ({
  forgotPassword: bindActionCreators(forgotPassword, dispatch),
  resetPassword: bindActionCreators(resetPassword, dispatch)
});

export default connect(mapStateToProps, mapDispatchToProps)(ForgotPassword);
