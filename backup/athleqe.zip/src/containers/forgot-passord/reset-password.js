import React from 'react';
import { LocalForm, Control } from 'react-redux-form';
import Errors from '../../components/common/errors';

export default ({ resetPassword, status }) => {
  return (
    status ? <div className="forgot-password-success-message forgot-password-login-success-message">
      <form>
        <div className="tick-icon">
          <i className="fas fa-check"></i>
        </div>
        <div className="heading-text">
          <span>Well done</span>
        </div>
        <div className="sub-heading-text">
          <span>Now, let’s move mountains</span>
        </div>
      </form>
    </div>
      :
      <div className="forgot-password reset-password">
        <LocalForm
          model="user"
          onSubmit={(values) => resetPassword(values)}
        >
         
          <div className="heading-text">
            <span>Reset your password</span>
          </div>
          <div className="form-group">
            <Control.text
              model="user.password"
              className="form-control"
              id="user.password"
              type="password"
              placeholder="New Password"
              errors={{
                required: (val) => !val || !val.length
              }}
            />
            <Errors
              model="user.password"
            />
          </div>
          <div className="form-group">
            <Control.text
              model="user.new_password"
              className="form-control"
              id="user.new_password"
              type="password"
              placeholder="Re-enter Password"
              errors={{
                required: (val) => !val || !val.length
              }}
            />
            <Errors
              model="user.new_password"
            />
          </div>
          <button type="submit" className="btn btn-primary">Submit
          </button>
        </LocalForm>
      </div>
  );
};