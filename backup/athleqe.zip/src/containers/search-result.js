/*
 * @file: search-result.js
 * @description: It is Container search result screen .
 * @author: smartData
 */
import React, { Component } from 'react';
import ReactStars from 'react-stars';

class SearchResult extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    return (
      <div class="content">
        <div className="search-page-list">
          <div className="row">
            <div className="col-md-6 col-sm-12">
              <div className="image-block">
                <div className="media">
                  <img src={require("../assets/images/Nudgit-Bob-DE.png")} alt="image" />
                  <div className="media-body">
                    <div className="full-desc">
                      <h5 className="mt-0">Bob McIntosh</h5>
                      <div className="star-image">
                        <ReactStars
                          count={5}
                          size={18}
                          value={3.5}
                          color2={'#D2F035'}
                        />
                      </div>
                      <div className="desc">
                        <p>$100/hr + fees</p>
                        <p>2016 Caterpillar 309CR</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 col-sm-12">
              <div className="image-block">
                <div className="media">
                  <img src={require("../assets/images/Nudgit-Bob-DE.png")} alt="image" />
                  <div className="media-body">
                    <div className="full-desc">
                      <h5 className="mt-0">Bob McIntosh</h5>
                      <div className="star-image">
                      <ReactStars
                          count={5}
                          size={18}
                          value={3.5}
                          color2={'#D2F035'}
                        />
                      </div>
                      <div className="desc">
                        <p>$100/hr + fees</p>
                        <p>2016 Caterpillar 309CR</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 col-sm-12">
              <div className="image-block">
                <div className="media">
                  <img src={require("../assets/images/Nudgit-Bob-DE.png")} alt="image" />
                  <div className="media-body">
                    <div className="full-desc">
                      <h5 className="mt-0">Bob McIntosh</h5>
                      <div className="star-image">
                      <ReactStars
                          count={5}
                          size={18}
                          value={3.5}
                          color2={'#D2F035'}
                        />
                      </div>
                      <div className="desc">
                        <p>$100/hr + fees</p>
                        <p>2016 Caterpillar 309CR</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 col-sm-12">
              <div className="image-block">
                <div className="media">
                  <img src={require("../assets/images/Nudgit-Bob-DE.png")} alt="image" />
                  <div className="media-body">
                    <div className="full-desc">
                      <h5 className="mt-0">Bob McIntosh</h5>
                      <div className="star-image">
                      <ReactStars
                          count={5}
                          size={18}
                          value={3.5}
                          color2={'#D2F035'}
                        />
                      </div>
                      <div className="desc">
                        <p>$100/hr + fees</p>
                        <p>2016 Caterpillar 309CR</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 col-sm-12">
              <div className="image-block">
                <div className="media">
                  <img src={require("../assets/images/Nudgit-Bob-DE.png")} alt="image" />
                  <div className="media-body">
                    <div className="full-desc">
                      <h5 className="mt-0">Bob McIntosh</h5>
                      <div className="star-image">
                      <ReactStars
                          count={5}
                          size={18}
                          value={3.5}
                          color2={'#D2F035'}
                        />
                      </div>
                      <div className="desc">
                        <p>$100/hr + fees</p>
                        <p>2016 Caterpillar 309CR</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default SearchResult;