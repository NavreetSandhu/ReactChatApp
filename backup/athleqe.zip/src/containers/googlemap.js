import React , { Component }  from 'react';
import {Map, InfoWindow, Marker, GoogleApiWrapper , Polygon} from 'google-maps-react';
import { GOOGLE_API_KEY } from '../utilities/constants';
import 'rc-tooltip/assets/bootstrap.css';
import 'rc-slider/assets/index.css';
import Slider from 'rc-slider';
import { Row, Col, Button, FormGroup, Label } from 'reactstrap';
import LocationSearch from '../components/LocationSearch';

//***********handle slider*******************************/
Slider.createSliderWithTooltip;

const colourStyles = {
    control: styles => ({ ...styles, backgroundColor: '#1c2024', color: 'blue' }),
    option: (styles, { data, isDisabled, isFocused, isSelected }) => {
        return {
            ...styles,
            color: 'black',
        };
    },

};

export class MapContainer extends Component {
   constructor(props) {
        super(props);
        this.state = {
            showingInfoWindow: false,
            activeMarker: {},
            selectedPlace: {},
          };
        this.onMarkerClick = this.onMarkerClick.bind(); 
        this.onMapClicked = this.onMapClicked.bind(); 
    }
         
  onMarkerClick = (props, marker, e) =>{
    this.setState({
      selectedPlace: props,
      activeMarker: marker,
      showingInfoWindow: true
    });
  };
  onMapClicked = (props) => {
    if (this.state.showingInfoWindow) {
      this.setState({
        showingInfoWindow: false,
        activeMarker: null
      });
    }
  };
    
  render() {
    var points = [
          {
              lat: this.props.lat_lng ? this.props.lat_lng[1] : 30.7333,
              lng: this.props.lat_lng ? this.props.lat_lng[0] : 76.7794
          }
       
    ];

    var bounds = new this.props.google.maps.LatLngBounds();
    for (var i = 0; i < points.length; i++) {
      bounds.extend(points[i]);
    }

    const style = {
        width: '100%',
        height: '100%'
      };

      return (
          
          <div
              className={`modal fade custom-fade ${this.props.popup && 'show d-block'}`}
              id="select-operator-popup-form"
              tabIndex="-1"
              role="dialog"
              aria-labelledby="select-operator-popup-formLabel"
              aria-hidden="true"
          >
              <div className="modal-dialog" role="document">
                  <div className="modal-content operator-modal-content">
                      <div className="modal-header">
                          <h5 className="modal-title" id="add-operator-popup-formLabel">
                              Add Location
                          </h5>
                          <button
                              type="button"
                              className="close"
                              data-dismiss="modal"
                              aria-label="Close"
                              onClick={() => {
                                  this.props.showHidePopup(false);
                                  
                              }}
                          >
                              <span aria-hidden="true">
                                  <i className="fa fa-close"></i>
                              </span>
                          </button>
                      </div>
                      <div className="modal-body" >
                          <div>
                          <Row>
                                  <Col sm="12">
                                      <FormGroup>
                                      <Label className="labell"> Location</Label>
                                          <LocationSearch placeholder="Enter your address" address={this.props.address} _getAddress={this.props.getAddress} />
                                      </FormGroup>
                                          </Col>
                                  <Col sm="12">
                                      <FormGroup>
                                          <Label className="labell"> Radius </Label> <p className="blue-color">{this.props.radius} meter</p>
                                      <Slider max="1000" onChange={value => this.props.updateRadius(value)} value={this.props.radius} tipFormatter={value => `${value} m`} />
                                      </FormGroup>
                                          </Col>
                              </Row>
                              <br></br>
                              <Row>
                                  <div>
                            <Map
                                google={this.props.google}
                                style={style}
                              initialCenter={{
                                  lat: this.props.lat_lng ? this.props.lat_lng[1] : 30.7333,
                                  lng: this.props.lat_lng ? this.props.lat_lng[0] : 76.7794
                              }}
                                bounds={bounds}
                                >
                              {points.map((val,index) =>       
                              <Marker
                                key={index} 
                                title={'The marker`s title will appear as a tooltip.'}
                                name={'SOMA'}
                                onClick={this.onMarkerClick}
                                position={{lat: val.lat, lng: val.lng}} 
                              />   
                              )}
                            <InfoWindow
                                marker={this.state.activeMarker}
                                visible={this.state.showingInfoWindow}>
                                <div>
                                <h1 className="mapText">{this.state.selectedPlace.name}</h1>
                                </div>
                            </InfoWindow>     
                                      </Map>
                                      </div>
                              </Row>
                          </div>
                      </div>
                  </div>
              </div >
          </div >
    );
  }
}
 
export default GoogleApiWrapper({
  apiKey: (GOOGLE_API_KEY)
})(MapContainer);