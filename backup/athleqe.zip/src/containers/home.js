/*
 * @file: home.js
 * @description: It is Container home screen .
 * @author: smartData
 */
import React, { Component } from 'react';
import LocationSearch from '../components/LocationSearch';

class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
    this.getAddress=this.getAddress.bind(this);
  }

  getAddress(address,lat_lng){
  console.log(address,lat_lng);
  }

  render() {
    return (
      <div className="row">
        <div className="col-md-2">
        </div>
        <div className="col-md-4">
          <div className="home-heading">
            <h1>a simple nudge can move mountains</h1>
          </div>
          <div className="sign-up-buttons">
            <div className="button">
              <button type="submit" onClick={() => this.props.history.push('/signup')}><img src={require('../assets/images/white-arrow.png')} alt="find" /> Sign up</button>
            </div>
            <div className="button">
              <button type="submit" onClick={() => this.props.history.push('/login')}><img src={require('../assets/images/white-arrow.png')} alt="find" /> My nudgits</button>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="login-form find-operator-form">
            <div className="heading">
              <h3>Find the right operator</h3>
            </div>
            <div className="sub-heading">
              <h4>to nudge your project in the right direction</h4>
            </div>
            <form>
              <div className="form-group">
                <a href="#">Service type <i className="fas fa-chevron-right"></i></a>
              </div>
              <div className="form-group">
                <a href="#">Machine type <i className="fas fa-chevron-right"></i></a>
              </div>
              <div className="form-group">
              <a href="#">Location</a>
              <LocationSearch  _getAddress={this.getAddress} />
              </div>
              <div className="form-group">
                <a href="#">When</a>
              </div>
              <button type="submit" className="btn btn-primary find-btn">Find <img className="white-arrow" src={require('../assets/images/white-arrow.png')} alt="find" /></button>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

export default Home;
