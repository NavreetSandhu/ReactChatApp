/*
 * @file: ProfileBasics.js
 * @description: It is Container file .
 * @author: smartData
 */

import React, { useRef, useState,useEffect } from 'react';
import PropTypes from 'prop-types';
import { LocalForm, Control } from 'react-redux-form';
import Errors from '../../components/common/errors';
import { Row, Col, Button, FormGroup, Label } from 'reactstrap';
import { invalidEmail, invalidPass, requiredName, skillRequired, locationRequired} from '../../utilities/message';
import { connect } from 'react-redux';
import { getFile } from '../../utilities/common';
import Select from 'react-select';
import LocationSearch from '../../components/LocationSearch';
import MapContainer from '../googlemap';
import ImageCrop from '../../containers/popups/imagecrop';
import 'rc-tooltip/assets/bootstrap.css';
import 'rc-slider/assets/index.css';
import Slider from 'rc-slider';
import Switch from "react-switch";

//***********handle slider*******************************/
const createSliderWithTooltip = Slider.createSliderWithTooltip;
const Range = createSliderWithTooltip(Slider.Range);

export default ({
    setPrice,price,activity,_handleActivity,
    skill_error, location_error, deleteImage,
    submit,ImageCropModal, toggleImageModal, openCropper, imageToCrop,
    _handleSignup, image, uploadPhoto, role, selectedSkills, onSelect, skills, address, getAddress, locationModal, toggleModal, updateLocation, lat_lng , radius ,updateRadius}) => {

    const colourStyles = {
        control: styles => ({ ...styles, backgroundColor: '#1c2024', color: 'blue' }),
        option: (styles, { data, isDisabled, isFocused, isSelected }) => {
            return {
                ...styles,
                color: 'black',
            };
        },

    };


    return (
          <div >
              <div className="heading">
                  <h3>Profile Basics</h3>
            </div>
            <div className="sub-heading">
                <h4>Step 3 </h4>
                </div>
              <div className="center-div">
    <LocalForm
      model="profilebasics"
      onSubmit={(values) => submit(values)}
    >
                    <Row >
                        <Col sm="4"></Col>
        <Col sm="4">
            <div className="profile-image text-center">
                <div className="images">
                                    {image != '' && image != "https://i.stack.imgur.com/l60Hf.png" &&
                                        <img src={image} alt="operator image" height="130" width="130" />
                                    }
                                    {image === "" &&
                                        <img src="https://i.stack.imgur.com/l60Hf.png" alt="operator image" height="130" width="130" />
                                    }

                       <label htmlFor="profileImage">
                                        <i className="fa fa-edit" >Upload Image</i>
                                        
                                    </label>
                                    {image != '' && image != "https://i.stack.imgur.com/l60Hf.png" &&
                                        <button type="text" onClick={deleteImage} className="btn btn-primary btn-sm">Delete</button>
                                    }
                                    <div className="form-group">
                                        {ImageCropModal && (
                                            <ImageCrop
                                                popup={ImageCropModal}
                                                image={imageToCrop}
                                                showHideImagePopup={status => toggleImageModal(status)}
                                                uploadPhoto={e => uploadPhoto(e, 'image')}
                                            />
                                        )}
                                    <input
                                           type="file"
                                           className="form-control-file profile-img d-none"
                                           id="profileImage"
                                           onChange={e => openCropper(e.target.files[0])}
                                    />
                    </div>
                 </div>
             </div>
                        </Col>
                        
                      </Row>
                      {role === 'professional' &&
                          <Row>
                              <Col sm="12">
                                  <FormGroup>
                                      <Label htmlFor="profilebasics.title"> Title</Label>
                                      <Control.text
                                          model="profilebasics.title"
                                          className="form-control"
                                          id="profilebasics.title"
                                          placeholder="Right Your Features"
                                          errors={{
                                              required: (val) => !val || !val.length,
                                          }}
                                      />
                                      <Errors
                                          model="profilebasics.title"
                                          errors={{
                                              requiredName
                                          }}
                                      />
                                  </FormGroup>
                              </Col>
                              <Col sm="12">
                                  <FormGroup>
                                      <Label htmlFor="user.skills">Key Skills</Label>
                                  <Select
                                      placeholder="Choose your key skills"
                                          isMulti={true}
                                          onChange={onSelect}
                                          options={skills.map(row => ({ label: row.skill, value: row.id }))}
                                />
                                {skill_error && <p className="error">{
                                        skillRequired
                                    }
                                </p>
                                }
                                  </FormGroup>
                          </Col>
                          <Col sm="7">
                                  <Label htmlFor="profilebasics.title">Location</Label>
                            <LocationSearch placeholder="Enter your address" address={address} _getAddress={getAddress} />
                            {location_error && <p className="error">{
                                locationRequired
                            }
                            </p>
                            }
                          </Col>
                          <Col sm="4">
                              <FormGroup>
                                  <Label htmlFor="profilebasics.radius">Radius area m.</Label>
                                  <Control.text
                                      model="profilebasics.radius"
                                      className="form-control"
                                      id="profilebasics.radius"
                                    type="number"
                                    max="1000"
                                      value={radius}
                                      onChange={e => updateRadius(e.target.value)}
                                      placeholder="Radius of action"
                                      errors={{
                                          required: (val) => !val || !val.length,
                                      }}
                                  />
                                  <Errors
                                      model="profilebasics.radius"
                                      errors={{
                                          requiredName
                                      }}
                                  />
                              </FormGroup>
                          </Col>
                          <Col sm="1">
                              <FormGroup>
                                <i onClick={() => toggleModal(true)} className="map-icon fa fa-map" />
                                  {locationModal && (
                                      <MapContainer 
                                          popup={locationModal}
                                          showHidePopup={status => toggleModal(status)}
                                          address={address}
                                          lat_lng={lat_lng}
                                          updateLocation={updateLocation}
                                          radius={radius}
                                          updateRadius={updateRadius}
                                          getAddress={getAddress}
                                      />
                                  )}
                              </FormGroup>
                        </Col>
                        <Col sm="7">
                            <FormGroup>
                                <Label htmlFor="profilebasics.skills">Activity Status(Taking new clients!)</Label>
                                <Switch onChange={_handleActivity} checked={activity} />
                            </FormGroup>
                        </Col>
                        <Col sm="5">
                            <FormGroup>
                                <Label htmlFor="profilebasics.currency">Currency</Label>
                                <Control.select
                                    model="profilebasics.currency"
                                    className="form-control"
                                    id="profilebasics.currency"
                                    errors={{ required: (val) => !val || !val.length, }}

                                >
                                    <option value="">Select Currency</option>
                                    <option value="USD">USD</option>
                                    <option value="AUD">AUD</option>
                                    <option value="CAD">CAD</option>
                                   
                                </Control.select>
                                <Errors
                                    model="profilebasics.currency"
                                    errors={{ requiredName }}
                                />
                            </FormGroup>
                        </Col>
                        <Col sm="12">
                            <FormGroup>
                                <Label htmlFor="user.skills">Price Range</Label>
                                <Range min={0} max={3000} onChange={value => setPrice(value)} value={price} tipFormatter={value => `${value}`} />

                            </FormGroup>
                        </Col>
                          </Row>
                      }
        <Row>
                        <Col sm="12">
                            <FormGroup>
                                <button type="submit"  className="btn btn-primary btn-block ">Save & Signup</button>
                            </FormGroup>
                            </Col>
        
      </Row>
                </LocalForm>

        </div >
            </div>
  );
 };

