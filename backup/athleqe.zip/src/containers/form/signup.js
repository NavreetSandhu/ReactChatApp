/*
 * @file: signup.js
 * @description: It is Container file .
 * @author: smartData
 */

import React , { useState }from 'react';
import PropTypes from 'prop-types';
import { LocalForm, Control } from 'react-redux-form';
import Errors from '../../components/common/errors';
import { Row, Col, Button, FormGroup, Label  } from 'reactstrap';
import Match from '../../utilities/validation';
import { invalidEmail, invalidPass, requiredName } from '../../utilities/message';
import DatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";

const SignupForm = ({ _handleRegistration, hidden,confirm_error}) => {

    const [date, setDate] = useState(new Date());

    const handleChange = date => {
        setDate(date);
    };

    return (
        <div >
            <div className="heading">
                <h3>Registration</h3>
            </div>
            <div className="sub-heading">
                <h4>( Step 2 )</h4>
                </div>
            <div className="center-div">
                <LocalForm 
                    model="user"
                    onSubmit={(values) => _handleRegistration(values, date)}
    >
                    <Row>
    <Col sm="6" >
        <FormGroup>
          <Label htmlFor="user.name">First Name</Label>
          <Control.text
            model="user.firstName"
            className="form-control"
            id="user.firstName"
            placeholder="Enter first name"
            errors={{
              required: (val) => !val || !val.length,
            }}
          />
          <Errors
            model="user.firstName"
            errors={{
              requiredName
            }}
          />
        </FormGroup>
      </Col>
      <Col sm="6">
        <FormGroup>
          <Label htmlFor="user.lastName">Last Name</Label>
          <Control.text
            model="user.lastName"
            className="form-control"
            id="user.lastName"
            placeholder="Enter Last Name"
            errors={{
              required: (val) => !val || !val.length,
            }}
          />
          <Errors
            model="user.lastName"
            errors={{
              requiredName
            }}
          />
        </FormGroup>
      </Col>
      <Col sm="12">
        <FormGroup>
          <Label htmlFor="user.email">Email</Label>
          <Control.text
            model="user.email"
            className="form-control"
            id="user.email"
            placeholder="Enter email"
            errors={{
              required: (val) => !val || !val.length,
              invalidEmail: (val) => !Match.validateEmail(val)
            }}
          />
          <Errors
            model="user.email"
            errors={{
              invalidEmail
            }}
          />
        </FormGroup>
      </Col>
      <Col sm="12">
        <FormGroup>
          <Label htmlFor="user.password">Password</Label>
          <Control.text
            model="user.password"
            className="form-control"
            id="user.password"
            type={hidden ? "text" : "password"}
            placeholder="Password"
            max="8"
            errors={{
              required: (val) => !val || !val.length,
              //invalidPass: (val) => !Match.validatePassword(val)
            }}
          />
          <Errors
            model="user.password"
            errors={{
              invalidPass
            }}
          />
        </FormGroup>
                        </Col>
                        <Col sm="12">
                            <FormGroup>
                                <Label htmlFor="user.confirmpassword">Confirm Password</Label>
                                <Control.text
                                    model="user.confirmpassword"
                                    className="form-control"
                                    id="user.confirmpassword"
                                    type={hidden ? "text" : "password"}
                                    placeholder="Confirm Password"
                                    errors={{
                                        required: (val) => !val || !val.length,
                                        //invalidPass: (val) => !Match.validatePassword(val)
                                    }}
                                />
                                <Errors
                                    model="user.confirmpassword"
                                    errors={{
                                        requiredName
                                    }}
                                />
                                {confirm_error &&
                                    <p className="error">Confirm password and password doesn't match</p>
                                }
                            </FormGroup>
                        </Col>
      <Col sm="12">
        <FormGroup>
          <Label htmlFor="user.password">Gender</Label>
          <Control.select
            model="user.gender"
            className="form-control"
            id="user.gender"
            errors={{required: (val) => !val || !val.length,}}
          >
          <option value="">Select Gender</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
          </Control.select>

          <Errors
                   model="user.gender"
                   errors={{ requiredName }}
          />
        </FormGroup>
        </Col>
        <Col sm="12">
          <FormGroup>
             <Label htmlFor="user.password">Date Of Birth</Label><br></br>
               <DatePicker
                   selected={date}
                   onChange={handleChange}
                />
          </FormGroup>
        </Col>
                        <Col sm="12">
                            <FormGroup>
                                <Label htmlFor="user.password">Where did you hear about us?</Label>
                                <Control.select
                                    model="user.enquiry"
                                    className="form-control"
                                    id="user.enquiry"
                                    errors={{ required: (val) => !val || !val.length, }}

                                >
                                    <option value="">Select Option</option>
                                    <option value="Email">Email</option>
                                    <option value="Message">Message</option>
                                    <option value="Friend/colleague">Friend/colleague</option>
                                    <option value="Search engine">Search engine</option>
                                    <option value="Other">Other</option>
                                </Control.select>
                                <Errors
                                    model="user.enquiry"
                                    errors={{ requiredName }}
                                />
                            </FormGroup>
                        </Col>
                        <Col sm="12">
                            <button type="submit" className="btn btn-primary btn-block ">Next</button>

      </Col>
      </Row>
                </LocalForm>
            </div>
        </div>
  );
};

SignupForm.propTypes = {
    _handleRegistration: PropTypes.func.isRequired
};
export default SignupForm;