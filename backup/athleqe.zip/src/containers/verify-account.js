import React, {useState, useEffect} from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { accountVerification } from '../actions/user';
import { Link } from 'react-router-dom';

export default ({match,history}) => {
    const user = useSelector(state => state.user);
    const dispatch = useDispatch();
    const [status, setStatus] = useState(false);
    useEffect(() => {
        if(!user.loggedIn){ 
            // action creator call here
            dispatch(accountVerification(match.params.token, res => {
                if (res) {
                    setStatus(true);
                }
            }));
        }
        
    });


    return (
      <div>
           
    <div className="login-form">
                {status &&
                    <div>
                    <div className="heading">
                    <h3>Well done…</h3>
                     <p>You Account has been verified successfully</p>
                    </div>
                    <div className="d-flex flex-column">
                              <Link to="/" className="green-font"><i className="fa fa-angle-left mr-1" aria-hidden="true"></i>Login</Link>
                    </div>
                </div>
                }
                {
                    !status &&
                    <div>
                        <div className="heading">
                            <h3>Token Expired</h3>
                        </div>
                    </div>

                }
            </div>
        </div>
  );
};

