import React from 'react';
import {StripeProvider} from 'react-stripe-elements';
 
import MyStoreCheckout from './checkoutstore';
 
const Stripe = () => {
  return (
    <div className="login-form">
    <StripeProvider apiKey="pk_test_8UPa353TPseBnLxkvyj97Dd700CQJTp1Y6">
      <MyStoreCheckout />
    </StripeProvider>
    </div>
  );
};

export default Stripe;
