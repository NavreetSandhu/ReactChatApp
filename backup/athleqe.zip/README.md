# Athleqe Application Using React.js
---
This is a repository for athleqe project
### Includes
- React
- Node
- Express
- Redux
### Run React
```
yarn install
yarn start
yarn build
```

### Run Server (Node)
```
yarn prod
```

```
- Application will run on http://localhost:3002